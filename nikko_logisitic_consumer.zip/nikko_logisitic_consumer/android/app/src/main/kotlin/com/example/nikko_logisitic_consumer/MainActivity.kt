package com.example.nikko_logisitic_consumer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
